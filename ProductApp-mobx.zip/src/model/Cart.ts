export default interface Cart {
    id: number;
    title: string;
    price: number;
    category: string;
    image: string;
    quantity: number;
    amount: number
  }